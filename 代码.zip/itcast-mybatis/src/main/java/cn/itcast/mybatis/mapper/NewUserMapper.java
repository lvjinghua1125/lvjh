package cn.itcast.mybatis.mapper;

import cn.itcast.mybatis.pojo.User;

import com.github.abel533.mapper.Mapper;

public interface NewUserMapper extends Mapper<User>{

}
